//
//  Services.swift
//  ErrrandApp
//
//  Created by Tabish on 10/12/20.
//

import Foundation

class Services {
    
    static let sharedInstance = Services()
}
